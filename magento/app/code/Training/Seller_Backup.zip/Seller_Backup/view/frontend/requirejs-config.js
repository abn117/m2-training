var config = {
    "map": {
        "*": {
            "menu": "js/navigation-menu",
            "mage/backend/menu": "js/navigation/menu"
        }
    }
};
